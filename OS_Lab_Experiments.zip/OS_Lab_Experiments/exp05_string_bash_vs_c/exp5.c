#include <stdio.h>

int main() {
    char str[200], sub[200];
    int len = 0, start, count, i;

    printf("Enter a string: ");
    scanf(" %[^\n]", str);

    /* length: walk until the null terminator */
    while (str[len] != '\0')
        len++;
    printf("Length of string: %d\n", len);

    printf("Enter starting position: ");
    scanf("%d", &start);
    printf("Enter number of characters: ");
    scanf("%d", &count);

    /* substring: copy characters into a buffer */
    for (i = 0; i < count && start + i < len; i++)
        sub[i] = str[start + i];
    sub[i] = '\0';

    printf("Substring: %s\n", sub);
    return 0;
}
