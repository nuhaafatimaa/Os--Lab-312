# Experiment 10: Observing virtual memory addresses across concurrent processes in C

## Aim
To print the address of a variable in the parent and child after `fork()` and in several concurrent instances of a program, and understand virtual addresses and ASLR.

## Theory
- `fork()` creates a child process; `&number` gives the memory address of a variable; `%p` prints it.
- Virtual memory: each process has its own private address space, translated by the MMU to physical memory.
- Concurrent processes: parent and child can execute in overlapping periods.
- After fork the child has a copy of the parent's address space, so the same variable has the **same virtual address** in both but sits in **different physical memory** (copy-on-write).
- **ASLR** randomises the stack, heap and library base addresses on every run, so separate runs or separate instances print different addresses.

## Programs / commands

**exp10.c**
```c
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int number = 10;
    pid_t pid = fork();

    if (pid == 0) {
        printf("Child process: address of number = %p, value = %d\n", (void *)&number, number);
    } else {
        printf("Parent process: address of number = %p, value = %d\n", (void *)&number, number);
        wait(NULL);
    }

    return 0;
}
```

**addr.c**
```c
#include <stdio.h>
#include <unistd.h>

int main() {
    int stack_var = 42;
    printf("PID: %d  Stack variable address: %p\n", getpid(), (void *)&stack_var);
    fflush(stdout);
    while (1) sleep(1);
    return 0;
}
```

**run.sh**
```bash
#!/bin/bash
cd "$(dirname "$0")"
echo '$ ./exp10   (parent and child after fork)'
./exp10
echo
echo '$ ./exp10   (run again - the address changes between runs: ASLR)'
./exp10
echo
echo '$ ./addr &   x4  (four concurrent instances)'
for i in 1 2 3 4; do ./addr > /tmp/addr$i.out & P[$i]=$!; done
sleep 1
for i in 1 2 3 4; do cat /tmp/addr$i.out; done
echo
echo -n '$ cat /proc/sys/kernel/randomize_va_space  ->  '; cat /proc/sys/kernel/randomize_va_space
echo "(2 = full ASLR)"
kill ${P[@]}; wait 2>/dev/null; rm -f /tmp/addr?.out
```

## Procedure
1. Save the files above in one folder.
2. Compile C files with `gcc name.c -o name` and make scripts executable with `chmod +x name.sh`.
3. Run `bash run.sh` (or run each command by hand) and compare with the output below.

## Output
```
$ ./exp10   (parent and child after fork)
Child process: address of number = 0x7ffce6a27810, value = 10
Parent process: address of number = 0x7ffce6a27810, value = 10

$ ./exp10   (run again - the address changes between runs: ASLR)
Child process: address of number = 0x7ffe3b0d4910, value = 10
Parent process: address of number = 0x7ffe3b0d4910, value = 10

$ ./addr &   x4  (four concurrent instances)
PID: 1550  Stack variable address: 0x7ffff3f3e464
PID: 1551  Stack variable address: 0x7fff91494314
PID: 1552  Stack variable address: 0x7ffd4e5a85a4
PID: 1553  Stack variable address: 0x7ffdaccf5334

$ cat /proc/sys/kernel/randomize_va_space  ->  2
(2 = full ASLR)
```

**Note:** Your screenshot also shows the same address in parent and child (0x7ffeedcc4a3c).

## Conclusion
Parent and child printed the same virtual address and value, proving each has its own copy of the address space. Different runs and different concurrent instances printed different stack addresses, showing ASLR (randomize_va_space = 2).

## Viva questions

**Q1. Why are parent and child addresses identical?**  
The child inherits a copy of the address space; the addresses are virtual, not physical.

**Q2. Does the same virtual address mean the same physical memory?**  
No, each process has its own page tables.

**Q3. What is ASLR?**  
Randomising memory layout on each run to make exploits harder.

**Q4. What does `%p` print?**  
A pointer value (memory address).
