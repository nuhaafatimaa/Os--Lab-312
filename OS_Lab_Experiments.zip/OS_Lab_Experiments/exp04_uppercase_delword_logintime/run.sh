#!/bin/bash
r() { echo "\$ $*"; eval "$@"; }
cd "$(dirname "$0")"; W=$(mktemp -d); cp *.sh todo.txt "$W"; cd "$W"
echo "### Part A: rename files to upper case"
touch file3.txt file4.txt new.txt
r ls
r ./upper.sh file3.txt file4.txt new.txt nofile.txt
r ls
echo
echo "### Part B: delete lines containing a word"
r cat todo.txt
r ./delword.sh error todo.txt
r cat todo.txt
r ./delword.sh error
echo
echo "### Part C: login duration of a user (simulated 'who', see note)"
mkdir bin
login=$(date -d '69 minutes ago' '+%Y-%m-%d %H:%M')
printf '#!/bin/bash\necho "nuhafatima console  %s"\n' "$login" > bin/who; chmod +x bin/who
echo "note: a mock 'who' is placed first in PATH so the output does not depend on this sandbox's sessions"
r 'PATH=$PWD/bin:$PATH who'
r 'PATH=$PWD/bin:$PATH ./logintime.sh nuhafatima'
r 'PATH=$PWD/bin:$PATH ./logintime.sh nobody'
cd /; rm -rf "$W"
