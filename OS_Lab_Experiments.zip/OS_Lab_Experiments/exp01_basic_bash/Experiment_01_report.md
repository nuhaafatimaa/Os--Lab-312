# Experiment 1: Practice Basic Bash, I/O Redirection, Pipe, File and Directory Operations, Searching Files, Process Management and Text Editors

## Aim
To practise basic bash commands by building the MIET directory tree (branches, CSE sections, AIML subjects) and using redirection, pipes, searching and process control on it.

## Theory
- `pwd` shows the current absolute path; `cd` changes directory; `cd ..` goes one level up.
- `mkdir` creates directories (`-p` makes nested ones); `rmdir` removes an empty directory; `rm -r` deletes a directory with everything inside.
- `ls` lists files, `ls -l` gives details, `ls -a` includes hidden files, `ls -R` lists recursively; `tree` draws the structure as a tree.
- `touch` creates an empty file, `cp` copies, `mv` renames or moves, `cat` shows a file, `head -n 1` shows the first line, `sort` sorts lines alphabetically.
- `>` overwrites a file with output, `>>` appends, `&>` redirects standard output and standard error together.
- `ls | grep "file1"` pipes the output of `ls` into `grep` to filter it.
- `find . -name "*.txt"` searches a directory tree by name.
- `sleep 100 &` runs a job in the background; `jobs`, `ps -o pid,ni,comm`, `kill -STOP/-CONT`, `nice -n 10` manage processes and priority.
- `nano` and `vi` are terminal text editors (`Ctrl+O` / `Ctrl+X` in nano, `:wq` in vi). They are interactive, so they are not part of the automated run.

## Programs / commands

**run.sh**
```bash
#!/bin/bash
# Run:  bash run.sh        (works in a scratch folder, nothing outside it is touched)
r() { echo "\$ $*"; eval "$@"; }
W=$(mktemp -d); cd "$W"
r pwd
r mkdir -p MIET/CSE MIET/BBA MIET/LAW MIET/ECE MIET/Civil MIET/BCOM
r cd MIET/CSE
r mkdir Core AIML Cyber
r cd AIML
r mkdir Maths DAA MDC OS Management
r cd Maths
r touch file1.txt
r echo '"Basic Bash Practical"'
r 'echo "Basic Bash Practical" > file1.txt'
r cp file1.txt file2.txt
r mv file2.txt notes.txt
r cat notes.txt
r 'echo "Second line" >> file1.txt'
r cat file1.txt
r ls -l
r ls -a
r 'ls /nonexistent_dir &> output.txt'
r cat output.txt
r 'printf "Banana\nApple\nCherry\n" > names.txt'
r sort names.txt
r head -n 1 names.txt
r 'ls | grep "file1"'
r cd ~-
r cd /
r 'cd "$W/MIET"'
r ls -R
r tree
r mkdir TestFolder
r rmdir TestFolder
r mkdir TestFolder2
r touch TestFolder2/sample.txt
r rm -r TestFolder2
r 'find . -name "*.txt"'
r 'sleep 100 &'
r jobs
r 'ps -o pid,ni,comm -p $!'
r 'kill -STOP $!'
r 'kill -CONT $!'
r 'nice -n 10 sleep 100 &'
r 'ps -o pid,ni,comm -p $!'
r 'kill %1 %2'
r 'sleep 1; jobs'
cd /; rm -rf "$W"
```

## Procedure
1. Save the files above in one folder.
2. Compile C files with `gcc name.c -o name` and make scripts executable with `chmod +x name.sh`.
3. Run `bash run.sh` (or run each command by hand) and compare with the output below.

## Output
```
$ pwd
/tmp/tmp.NspQ6U3sgC
$ mkdir -p MIET/CSE MIET/BBA MIET/LAW MIET/ECE MIET/Civil MIET/BCOM
$ cd MIET/CSE
$ mkdir Core AIML Cyber
$ cd AIML
$ mkdir Maths DAA MDC OS Management
$ cd Maths
$ touch file1.txt
$ echo "Basic Bash Practical"
Basic Bash Practical
$ echo "Basic Bash Practical" > file1.txt
$ cp file1.txt file2.txt
$ mv file2.txt notes.txt
$ cat notes.txt
Basic Bash Practical
$ echo "Second line" >> file1.txt
$ cat file1.txt
Basic Bash Practical
Second line
$ ls -l
total 8
-rw-r--r-- 1 root root 33 Nov  3 05:22 file1.txt
-rw-r--r-- 1 root root 21 Nov  3 05:22 notes.txt
$ ls -a
.
..
file1.txt
notes.txt
$ ls /nonexistent_dir &> output.txt
$ cat output.txt
ls: cannot access '/nonexistent_dir': No such file or directory
$ printf "Banana\nApple\nCherry\n" > names.txt
$ sort names.txt
Apple
Banana
Cherry
$ head -n 1 names.txt
Banana
$ ls | grep "file1"
file1.txt
$ cd /tmp/tmp.NspQ6U3sgC/MIET/CSE/AIML
$ cd /
$ cd "$W/MIET"
$ ls -R
.:
BBA
BCOM
CSE
Civil
ECE
LAW

./BBA:

./BCOM:

./CSE:
AIML
Core
Cyber

./CSE/AIML:
DAA
MDC
Management
Maths
OS

./CSE/AIML/DAA:

./CSE/AIML/MDC:

./CSE/AIML/Management:

./CSE/AIML/Maths:
file1.txt
names.txt
notes.txt
output.txt

./CSE/AIML/OS:

./CSE/Core:

./CSE/Cyber:

./Civil:

./ECE:

./LAW:
$ tree
.
|-- BBA
|-- BCOM
|-- CSE
|   |-- AIML
|   |   |-- DAA
|   |   |-- MDC
|   |   |-- Management
|   |   |-- Maths
|   |   |   |-- file1.txt
|   |   |   |-- names.txt
|   |   |   |-- notes.txt
|   |   |   `-- output.txt
|   |   `-- OS
|   |-- Core
|   `-- Cyber
|-- Civil
|-- ECE
`-- LAW

15 directories, 4 files
$ mkdir TestFolder
$ rmdir TestFolder
$ mkdir TestFolder2
$ touch TestFolder2/sample.txt
$ rm -r TestFolder2
$ find . -name "*.txt"
./CSE/AIML/Maths/names.txt
./CSE/AIML/Maths/output.txt
./CSE/AIML/Maths/notes.txt
./CSE/AIML/Maths/file1.txt
$ sleep 100 &
$ jobs
[1]+  Running                 sleep 100 &
$ ps -o pid,ni,comm -p $!
  PID  NI COMMAND
 1345   0 sleep
$ kill -STOP $!
$ kill -CONT $!
$ nice -n 10 sleep 100 &
$ ps -o pid,ni,comm -p $!
  PID  NI COMMAND
 1347  10 sleep
$ kill %1 %2
$ sleep 1; jobs
```

## Conclusion
The MIET tree (6 branches, 3 CSE sections, 5 AIML subjects: 15 directories) was created and navigated, files were created, copied, renamed and redirected, a pipe and find were used, and background jobs were stopped, resumed and re-prioritised with nice.

## Viva questions

**Q1. Difference between `rm`, `rmdir` and `rm -r`?**  
`rm` deletes files, `rmdir` only empty directories, `rm -r` a directory and all its contents.

**Q2. Difference between `>` and `>>`?**  
`>` overwrites the file, `>>` appends to it.

**Q3. What does `&>` do?**  
Sends both stdout and stderr to the same file.

**Q4. What does a pipe do?**  
Feeds the output of one command as the input of the next.

**Q5. What does `&` at the end of a command do?**  
Runs it in the background so the terminal stays free.
