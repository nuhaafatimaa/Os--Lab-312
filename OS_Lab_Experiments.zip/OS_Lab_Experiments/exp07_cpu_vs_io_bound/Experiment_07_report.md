# Experiment 7: OS scheduler dynamics, CPU utilisation and process states

## Aim
To run a CPU-bound and an I/O-bound program together in the background and compare their CPU share, state and priority with `ps` and `top`.

## Theory
- **CPU-bound** process: computes continuously, ~100% CPU, state **R** (running/runnable).
- **I/O-bound** process: writes to a file then `sleep()`s, ~0% CPU, state **S** (interruptible sleep).
- `&` runs a job in the background; `top -p PID` (Linux) or `top -pid PID` (macOS) watches specific processes.
- **NI** is the nice value (-20 highest priority, 19 lowest); `renice` changes it for a running process.
- `cpu_bound.c` is your program (prints a counter forever). `cpu_spin.c` is the same idea without printing, used for the measurement so the terminal is not flooded.

## Programs / commands

**cpu_bound.c**
```c
#include <stdio.h>

int main()
{
    unsigned long long i = 0;
    while (1)
    {
        printf("CPU task running : %llu\n", i++);
    }
    return 0;
}
```

**cpu_spin.c**
```c
/* Pure arithmetic loop (no printing) - saturates one core, state R */
int main()
{
    volatile unsigned long long x = 0;
    while (1)
    {
        x = x * 3 + 1;
        x = x / 2 + 7;
    }
    return 0;
}
```

**io_bound.c**
```c
#include <stdio.h>
#include <unistd.h>

int main()
{
    int i = 0;
    while (1)
    {
        FILE *fp = fopen("io_output.txt", "a");
        if (fp == NULL) { perror("fopen"); return 1; }
        fprintf(fp, "I/O task write number %d\n", i++);
        fclose(fp);
        sleep(1);
    }
    return 0;
}
```

**run.sh**
```bash
#!/bin/bash
cd "$(dirname "$0")"; rm -f io_output.txt
echo '$ ./cpu_spin &'; ./cpu_spin & CPU=$!
echo '$ ./io_bound &'; ./io_bound & IO=$!
echo "[cpu_spin PID=$CPU]  [io_bound PID=$IO]"
sleep 4
echo
echo '$ ps -o pid,stat,ni,pri,pcpu,comm -p '$CPU,$IO
ps -o pid,stat,ni,pri,pcpu,comm -p $CPU,$IO
echo
echo '$ top -b -n 1 -p '$CPU,$IO
top -b -n 1 -p $CPU,$IO | sed -n '1,4p;7,12p'
echo
echo '$ renice -n 10 -p '$CPU
renice -n 10 -p $CPU
ps -o pid,stat,ni,pcpu,comm -p $CPU,$IO
echo
echo '$ ./cpu_bound   (the printing version, first and last lines of 1 second of output)'
timeout 1 ./cpu_bound > /tmp/cpu_out.txt; sed -i '$d' /tmp/cpu_out.txt; head -n 3 /tmp/cpu_out.txt; echo ...; tail -n 2 /tmp/cpu_out.txt
echo
echo '$ cat io_output.txt'
cat io_output.txt
kill $CPU $IO; wait 2>/dev/null; rm -f io_output.txt /tmp/cpu_out.txt
echo
echo "cpu_spin: state R, ~100% CPU   |   io_bound: state S, ~0% CPU"
```

## Procedure
1. Save the files above in one folder.
2. Compile C files with `gcc name.c -o name` and make scripts executable with `chmod +x name.sh`.
3. Run `bash run.sh` (or run each command by hand) and compare with the output below.

## Output
```
$ ./cpu_spin &
$ ./io_bound &
[cpu_spin PID=1709]  [io_bound PID=1710]

$ ps -o pid,stat,ni,pri,pcpu,comm -p 1709,1710
  PID STAT  NI PRI %CPU COMMAND
 1709 R      0  19 99.0 cpu_spin
 1710 S      0  19  0.0 io_bound

$ top -b -n 1 -p 1709,1710
top - 05:22:58 up 4 min,  0 user,  load average: 0.19, 0.09, 0.03
Tasks:   2 total,   1 running,   1 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us,  0.0 sy,  0.0 ni, 50.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st 
MiB Mem :   8027.6 total,   7267.1 free,    471.0 used,    513.6 buff/cache     
  PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
 1709 root      20   0    2580   1224   1116 R  90.9   0.0   0:04.17 cpu_spin
 1710 root      20   0    2712   1804   1684 S   0.0   0.0   0:00.00 io_bound

$ renice -n 10 -p 1709
1709 (process ID) old priority 0, new priority 10
  PID STAT  NI %CPU COMMAND
 1709 RN    10 99.0 cpu_spin
 1710 S      0  0.0 io_bound

$ ./cpu_bound   (the printing version, first and last lines of 1 second of output)
CPU task running : 0
CPU task running : 1
CPU task running : 2
...
CPU task running : 13582139
CPU task running : 13582140

$ cat io_output.txt
I/O task write number 0
I/O task write number 1
I/O task write number 2
I/O task write number 3
I/O task write number 4
I/O task write number 5
I/O task write number 6

cpu_spin: state R, ~100% CPU   |   io_bound: state S, ~0% CPU
```

**Note:** Captured with Linux `top -b`. In your screenshot macOS `top` shows the process `7a` at 100% CPU, state `running`.

## Conclusion
cpu_spin showed state R and about 100% CPU while io_bound showed state S and 0.0% CPU, both at the default nice value 0. After `renice -n 10` the CPU-bound process showed NI 10 (state RN).

## Viva questions

**Q1. Why is io_bound in state S?**  
It spends nearly all its time in sleep() waiting for a timer.

**Q2. Why does cpu_spin show ~100%?**  
It never waits, so it keeps one core fully busy.

**Q3. What is NI?**  
The nice value, a priority hint from -20 to 19.

**Q4. Difference between S and D?**  
S can be interrupted by signals; D (uninterruptible, usually disk I/O) cannot.
