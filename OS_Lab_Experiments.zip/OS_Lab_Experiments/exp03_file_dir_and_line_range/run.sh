#!/bin/bash
r() { echo "\$ $*"; eval "$@"; }
cd "$(dirname "$0")"; mkdir -p MIET
echo "### Part A: file / directory check"
r 'echo MIET | ./checkfd.sh'
r 'echo manual.c | ./checkfd.sh' >/dev/null 2>&1
touch manual.c
r 'echo manual.c | ./checkfd.sh'
r 'echo abc | ./checkfd.sh'
rm -f manual.c; rmdir MIET
echo
echo "### Part B: display lines between two line numbers"
r cat notes.txt
r ./linerange.sh notes.txt 3 6
r ./linerange.sh missing.txt 1 2
