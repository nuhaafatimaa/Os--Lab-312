# Experiment 3: Shell scripts: file/directory check and displaying lines between two line numbers

## Aim
To write a script that reports whether a given name is a file, a directory or neither, and a script that prints the lines between two given line numbers of a file.

## Theory
- `read n` stores typed input in variable `n`.
- `[ -d "$n" ]` is true for a directory and `[ -f "$n" ]` for a regular file; `if / elif / else` selects the branch.
- `$1 $2 $3` are command line arguments; `sed -n "3,6p"` prints only lines 3 to 6.
- `[ ! -f "$file" ]` and `exit 1` handle a missing file.

## Programs / commands

**checkfd.sh**
```bash
#!/bin/bash
# Reads a name and reports whether it is a file, a directory, or neither
echo "Enter a file or directory"
read n
if [ -d "$n" ]
then
    echo "$n is a directory"
elif [ -f "$n" ]
then
    echo "$n is a file"
else
    echo "$n is neither directory nor file"
fi
```

**linerange.sh**
```bash
#!/bin/bash
# usage: ./linerange.sh file start end
file=$1
start=$2
end=$3

if [ ! -f "$file" ]; then
    echo "$file does not exist"
    exit 1
fi

sed -n "${start},${end}p" "$file"
```

**notes.txt**
```
1 introduction to shells
2 bash vs zsh
3 file permissions
4 io redirection
5 pipes and filters
6 process management
7 vi and nano basics
```

**run.sh**
```bash
#!/bin/bash
r() { echo "\$ $*"; eval "$@"; }
cd "$(dirname "$0")"; mkdir -p MIET
echo "### Part A: file / directory check"
r 'echo MIET | ./checkfd.sh'
r 'echo manual.c | ./checkfd.sh' >/dev/null 2>&1
touch manual.c
r 'echo manual.c | ./checkfd.sh'
r 'echo abc | ./checkfd.sh'
rm -f manual.c; rmdir MIET
echo
echo "### Part B: display lines between two line numbers"
r cat notes.txt
r ./linerange.sh notes.txt 3 6
r ./linerange.sh missing.txt 1 2
```

## Procedure
1. Save the files above in one folder.
2. Compile C files with `gcc name.c -o name` and make scripts executable with `chmod +x name.sh`.
3. Run `bash run.sh` (or run each command by hand) and compare with the output below.

## Output
```
### Part A: file / directory check
$ echo MIET | ./checkfd.sh
Enter a file or directory
MIET is a directory
$ echo manual.c | ./checkfd.sh
Enter a file or directory
manual.c is a file
$ echo abc | ./checkfd.sh
Enter a file or directory
abc is neither directory nor file

### Part B: display lines between two line numbers
$ cat notes.txt
1 introduction to shells
2 bash vs zsh
3 file permissions
4 io redirection
5 pipes and filters
6 process management
7 vi and nano basics
$ ./linerange.sh notes.txt 3 6
3 file permissions
4 io redirection
5 pipes and filters
6 process management
$ ./linerange.sh missing.txt 1 2
missing.txt does not exist
```

## Conclusion
The first script correctly identified a directory, a file and a non-existent name, and the second printed exactly lines 3 to 6 of notes.txt and refused a missing file.

## Viva questions

**Q1. What do `-d` and `-f` test?**  
`-d` tests for a directory, `-f` for a regular file.

**Q2. What does `sed -n` do?**  
Suppresses automatic printing so only lines selected with `p` appear.

**Q3. What does `$1` hold?**  
The first command line argument.
