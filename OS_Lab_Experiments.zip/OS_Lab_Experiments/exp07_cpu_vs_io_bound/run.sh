#!/bin/bash
cd "$(dirname "$0")"; rm -f io_output.txt
echo '$ ./cpu_spin &'; ./cpu_spin & CPU=$!
echo '$ ./io_bound &'; ./io_bound & IO=$!
echo "[cpu_spin PID=$CPU]  [io_bound PID=$IO]"
sleep 4
echo
echo '$ ps -o pid,stat,ni,pri,pcpu,comm -p '$CPU,$IO
ps -o pid,stat,ni,pri,pcpu,comm -p $CPU,$IO
echo
echo '$ top -b -n 1 -p '$CPU,$IO
top -b -n 1 -p $CPU,$IO | sed -n '1,4p;7,12p'
echo
echo '$ renice -n 10 -p '$CPU
renice -n 10 -p $CPU
ps -o pid,stat,ni,pcpu,comm -p $CPU,$IO
echo
echo '$ ./cpu_bound   (the printing version, first and last lines of 1 second of output)'
timeout 1 ./cpu_bound > /tmp/cpu_out.txt; sed -i '$d' /tmp/cpu_out.txt; head -n 3 /tmp/cpu_out.txt; echo ...; tail -n 2 /tmp/cpu_out.txt
echo
echo '$ cat io_output.txt'
cat io_output.txt
kill $CPU $IO; wait 2>/dev/null; rm -f io_output.txt /tmp/cpu_out.txt
echo
echo "cpu_spin: state R, ~100% CPU   |   io_bound: state S, ~0% CPU"
