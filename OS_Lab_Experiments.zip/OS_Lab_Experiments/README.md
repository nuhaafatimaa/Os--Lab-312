# OS / Shell Lab - Experiments 1 to 10

Each folder contains: the source files (.sh / .c), `run.sh` (runs the whole experiment), `output.txt` (captured output) and `Experiment_NN_report.md` (aim, theory, programs, output, conclusion, viva questions).

| # | Folder | Topic |
|---|---|---|
| 1 | exp01_basic_bash | Basic bash, I/O redirection, pipe, file/directory ops, find, process management (MIET tree) |
| 2 | exp02_date_who_sed | `date; who > file`, sed swap of first two words, `-i.bak` |
| 3 | exp03_file_dir_and_line_range | File-or-directory check script, lines between two line numbers |
| 4 | exp04_uppercase_delword_logintime | Rename to upper case, delete lines with a word, login duration |
| 5 | exp05_string_bash_vs_c | String length / substring in Bash and C, `time` |
| 6 | exp06_demand_paging | malloc + page touching, VSZ vs RSS |
| 7 | exp07_cpu_vs_io_bound | CPU-bound vs I/O-bound, states R and S, nice |
| 8 | exp08_pmap_memory_map | pmap -x, Dirty <= RSS <= Kbytes |
| 9 | exp09_fork_wait_pid | fork(), wait(), PID, zombie |
| 10 | exp10_virtual_address_fork | Virtual addresses across fork and concurrent processes, ASLR |

## About the outputs
The outputs were produced by really running every program and script on a Linux machine, not typed by hand.
Your lab record was done on a Mac, so a few things differ in your own terminal:
- prompt and `ls`/`ps` column layout, PIDs, addresses and times (they change every run);
- Exp 6: use `vm_stat` instead of `free`; Exp 7: `top -pid <PID>`; Exp 8: `vmmap <PID>` instead of `pmap`;
- Exp 4 (login time) uses a mock `who` in the captured output so it is repeatable; on your Mac it uses the real `who`.
Run `bash run.sh` in each folder on your Mac (compile the C files first with `gcc file.c -o file`) and paste your own output into the record if your teacher wants Mac output.
