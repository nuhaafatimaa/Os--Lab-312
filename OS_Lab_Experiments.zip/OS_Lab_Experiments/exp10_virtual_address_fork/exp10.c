#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int number = 10;
    pid_t pid = fork();

    if (pid == 0) {
        printf("Child process: address of number = %p, value = %d\n", (void *)&number, number);
    } else {
        printf("Parent process: address of number = %p, value = %d\n", (void *)&number, number);
        wait(NULL);
    }

    return 0;
}
