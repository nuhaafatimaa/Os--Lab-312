#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        exit(1);
    }
    else if (pid == 0)
    {
        /* child */
        printf("The child process ID (PID) is: %d\n", getpid());
        printf("The parent process ID (PPID) of child is: %d\n", getppid());
        sleep(1);
        printf("Child process finished.\n");
        exit(0);
    }
    else
    {
        /* parent */
        printf("The parent process (PID %d) waits until the child process finishes execution.\n", getpid());
        wait(NULL);                         /* reaps child, no zombie */
        printf("The PID of the child process is: %d\n", pid);
    }
    return 0;
}
