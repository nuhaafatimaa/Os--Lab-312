#include <stdio.h>

int main()
{
    unsigned long long i = 0;
    while (1)
    {
        printf("CPU task running : %llu\n", i++);
    }
    return 0;
}
