import pty, os, sys, select, time
cmd, answers = sys.argv[1], sys.argv[2:]
pid, fd = pty.fork()
if pid == 0:
    os.execvp(cmd, [cmd])
buf = b""; i = 0
def pump(t=0.4):
    global buf
    while select.select([fd], [], [], t)[0]:
        try: d = os.read(fd, 1024)
        except OSError: return False
        if not d: return False
        sys.stdout.write(d.decode().replace("\r", "")); sys.stdout.flush()
    return True
while True:
    alive = pump()
    if i < len(answers) and alive:
        os.write(fd, (answers[i] + "\n").encode()); i += 1
    elif not alive: break
    elif i >= len(answers):
        if not pump(0.5): break
        break
os.waitpid(pid, 0)
