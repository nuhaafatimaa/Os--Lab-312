#!/bin/bash
# Run:  bash run.sh        (works in a scratch folder, nothing outside it is touched)
r() { echo "\$ $*"; eval "$@"; }
W=$(mktemp -d); cd "$W"
r pwd
r mkdir -p MIET/CSE MIET/BBA MIET/LAW MIET/ECE MIET/Civil MIET/BCOM
r cd MIET/CSE
r mkdir Core AIML Cyber
r cd AIML
r mkdir Maths DAA MDC OS Management
r cd Maths
r touch file1.txt
r echo '"Basic Bash Practical"'
r 'echo "Basic Bash Practical" > file1.txt'
r cp file1.txt file2.txt
r mv file2.txt notes.txt
r cat notes.txt
r 'echo "Second line" >> file1.txt'
r cat file1.txt
r ls -l
r ls -a
r 'ls /nonexistent_dir &> output.txt'
r cat output.txt
r 'printf "Banana\nApple\nCherry\n" > names.txt'
r sort names.txt
r head -n 1 names.txt
r 'ls | grep "file1"'
r cd ~-
r cd /
r 'cd "$W/MIET"'
r ls -R
r tree
r mkdir TestFolder
r rmdir TestFolder
r mkdir TestFolder2
r touch TestFolder2/sample.txt
r rm -r TestFolder2
r 'find . -name "*.txt"'
r 'sleep 100 &'
r jobs
r 'ps -o pid,ni,comm -p $!'
r 'kill -STOP $!'
r 'kill -CONT $!'
r 'nice -n 10 sleep 100 &'
r 'ps -o pid,ni,comm -p $!'
r 'kill %1 %2'
r 'sleep 1; jobs'
cd /; rm -rf "$W"
