#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int global_var = 10;          /* data segment */

int main()
{
    int local_var = 5;                                  /* stack */
    char *small = malloc(1000);                         /* small block -> [heap] (brk) */
    small[0] = 1;
    char *heap = malloc(10 * 1024 * 1024);              /* large block -> mmap region  */
    for (int i = 0; i < 10 * 1024 * 1024; i += 4096)
        heap[i] = 1;

    printf("PID: %d\n", getpid());
    printf("Code  (main)   : %p\n", (void *)main);
    printf("Data  (global) : %p\n", (void *)&global_var);
    printf("Heap  (small)  : %p\n", (void *)small);
    printf("Heap  (10 MB)  : %p\n", (void *)heap);
    printf("Stack (local)  : %p\n", (void *)&local_var);
    fflush(stdout);
    sleep(600);
    return 0;
}
