#!/bin/bash
cd "$(dirname "$0")"
echo '$ ./exp6 100 &'
stdbuf -oL ./exp6 100 &
PID=$!
sleep 1
echo '$ ps -o pid,vsz,rss,comm -p '$PID' (KB)'
ps -o pid,vsz,rss,comm -p $PID
echo '$ free -m'
free -m
kill $PID; wait $PID 2>/dev/null
echo
echo "### Demand paging observed step by step (exp6_lazy 200)"
before=$(free -m | awk '/Mem:/{print $3}')
./exp6_lazy 200 &
PID=$!
for t in 1 2 3 4 5; do
  sleep 1
  printf 't=%ss  ' $t
  ps -o vsz=,rss= -p $PID | awk '{printf "VSZ=%d MB  RSS=%d MB\n",$1/1024,$2/1024}'
done
after=$(free -m | awk '/Mem:/{print $3}')
echo "system 'used' memory: before=${before} MB  after=${after} MB"
kill $PID; wait $PID 2>/dev/null
echo
echo "VSZ jumped as soon as malloc() ran; RSS stayed near 0 until the pages were written (t>=3s)."
