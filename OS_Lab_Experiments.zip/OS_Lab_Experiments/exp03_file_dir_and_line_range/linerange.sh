#!/bin/bash
# usage: ./linerange.sh file start end
file=$1
start=$2
end=$3

if [ ! -f "$file" ]; then
    echo "$file does not exist"
    exit 1
fi

sed -n "${start},${end}p" "$file"
