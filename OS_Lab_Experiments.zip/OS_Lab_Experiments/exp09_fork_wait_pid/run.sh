#!/bin/bash
cd "$(dirname "$0")"
echo '$ gcc experiment9.c -o experiment9'
echo '$ ./experiment9'
./experiment9
echo
echo "### Zombie demonstration (parent does NOT wait)"
cat > /tmp/zombie.c <<'Z'
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(){pid_t p=fork();if(p==0){exit(0);}sleep(3);return 0;}
Z
gcc -o /tmp/zombie /tmp/zombie.c
/tmp/zombie & ZP=$!
sleep 1
echo '$ ps -o pid,ppid,stat,comm --ppid '$ZP
ps -o pid,ppid,stat,comm --ppid $ZP
echo "(state Z = zombie: child finished but parent never called wait())"
wait $ZP; rm -f /tmp/zombie /tmp/zombie.c
