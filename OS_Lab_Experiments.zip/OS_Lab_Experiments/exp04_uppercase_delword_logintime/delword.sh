#!/bin/bash
# usage: ./delword.sh word file1 file2 ...
# Deletes every line containing the word from each file
word=$1
shift

if [ -z "$word" ] || [ "$#" -eq 0 ]; then
    echo "usage: ./delword.sh word file1 [file2 ...]"
    exit 1
fi

for file in "$@"
do
    if [ -f "$file" ]; then
        sed -i.bak "/$word/d" "$file" && rm -f "$file.bak"
        echo "removed lines containing '$word' from $file"
    else
        echo "$file does not exist"
    fi
done
