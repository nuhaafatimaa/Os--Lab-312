#!/bin/bash
export TZ=IST-5:30
r() { echo "\$ $*"; eval "$@"; }
cd "$(dirname "$0")"; cp name.txt work.txt
echo "### Part A: date on screen, who output redirected to a file"
r 'date; who > who.txt'
r cat who.txt
echo "(who.txt is empty here only because this sandbox has no logged-in terminal users; on your Mac it lists your sessions)"
r 'date; w | cat > w.txt'
r cat w.txt
echo
echo "### Part B: sed - swap first and second word of every line"
r cat work.txt
r "sed -E 's/^([^ ]+) ([^ ]+)/\2 \1/' work.txt"
r "sed -i.bak 's/^\([^ ]*\) \(.*\)$/\2 \1/' work.txt"
r cat work.txt
r cat work.txt.bak
rm -f who.txt w.txt work.txt work.txt.bak
