#!/bin/bash
cd "$(dirname "$0")"
echo '$ ./exp10   (parent and child after fork)'
./exp10
echo
echo '$ ./exp10   (run again - the address changes between runs: ASLR)'
./exp10
echo
echo '$ ./addr &   x4  (four concurrent instances)'
for i in 1 2 3 4; do ./addr > /tmp/addr$i.out & P[$i]=$!; done
sleep 1
for i in 1 2 3 4; do cat /tmp/addr$i.out; done
echo
echo -n '$ cat /proc/sys/kernel/randomize_va_space  ->  '; cat /proc/sys/kernel/randomize_va_space
echo "(2 = full ASLR)"
kill ${P[@]}; wait 2>/dev/null; rm -f /tmp/addr?.out
