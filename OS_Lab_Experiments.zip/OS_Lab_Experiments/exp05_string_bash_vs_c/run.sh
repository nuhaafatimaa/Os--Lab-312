#!/bin/bash
cd "$(dirname "$0")"
TIMEFORMAT='real %3Rs  user %3Us  sys %3Ss'
echo "### Bash version (exp5.sh)"
echo '$ ./exp5.sh'
python3 feed.py ./exp5.sh 'hello world' 2 7
echo
echo "### C version (exp5)"
echo '$ ./exp5'
python3 feed.py ./exp5 'hello world' 3 6
echo
echo "### Timing one run each"
echo '$ time ./exp5.sh'
time (printf 'hello world\n2\n7\n' | ./exp5.sh >/dev/null)
echo '$ time ./exp5'
time (printf 'hello world\n3\n6\n' | ./exp5 >/dev/null)
echo
echo "### Fair benchmark: same operation repeated 100000 times"
cat > /tmp/bench.sh <<'B'
str="Model Institute of Engineering and Technology"
for ((i=0;i<100000;i++)); do len=${#str}; sub=${str:6:9}; done
echo "bash: length=$len substring=$sub"
B
cat > /tmp/bench.c <<'B'
#include <stdio.h>
int main(){char s[]="Model Institute of Engineering and Technology",sub[50];int len=0,i,n;volatile int sink=0;
for(n=0;n<100000;n++){len=0;while(s[len])len++;for(i=0;i<9;i++)sub[i]=s[6+i];sub[9]=0;sink+=len+sub[0];}
printf("C   : length=%d substring=%s\n",len,sub);return 0;}
B
gcc -O0 -o /tmp/bench /tmp/bench.c
echo '$ time bash bench.sh'
time bash /tmp/bench.sh
echo '$ time ./bench'
time /tmp/bench
rm -f /tmp/bench /tmp/bench.c /tmp/bench.sh
