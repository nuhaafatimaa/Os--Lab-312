/* Same as exp6.c but touches the pages AFTER a pause, so the jump in RSS
   (page faults) can be observed separately from the malloc (VSZ) step. */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    if (argc != 2) { printf("Usage: %s <memory_in_MB>\n", argv[0]); return 1; }
    int mb = atoi(argv[1]);
    char *memory = malloc((size_t)mb * 1024 * 1024);
    if (memory == NULL) { printf("Memory allocation failed\n"); return 1; }

    printf("malloc done: %d MB reserved (virtual only)\n", mb); fflush(stdout);
    sleep(3);

    for (size_t i = 0; i < (size_t)mb * 1024 * 1024; i += 4096)
        memory[i] = 1;                       /* one write per 4096-byte page */
    printf("all pages touched\n"); fflush(stdout);

    while (1) sleep(1);
    return 0;
}
