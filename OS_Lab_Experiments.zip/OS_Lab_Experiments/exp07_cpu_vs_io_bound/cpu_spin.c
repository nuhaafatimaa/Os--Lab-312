/* Pure arithmetic loop (no printing) - saturates one core, state R */
int main()
{
    volatile unsigned long long x = 0;
    while (1)
    {
        x = x * 3 + 1;
        x = x / 2 + 7;
    }
    return 0;
}
