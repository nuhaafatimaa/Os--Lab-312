# Experiment 6: Virtual address space, demand paging and physical RAM consumption

## Aim
To allocate N MB with `malloc()`, write one byte every 4096 bytes (one per page) and observe that virtual size (VSZ) grows at allocation while physical memory (RSS) grows only when pages are touched.

## Theory
- `malloc()` only reserves virtual address space; no physical frame is assigned yet.
- Writing to a page for the first time causes a **page fault**; the kernel then maps a physical frame (demand paging).
- Writing every 4096 bytes touches each page exactly once (the page size on most x86 systems). Apple Silicon Macs use 16384-byte pages, as shown by `vm_stat` in your screenshot.
- **VSZ** = virtual memory reserved, **RSS** = part of it actually in RAM.
- Linux tools: `free -h`, `watch -n 1 free -h`, `ps -o vsz,rss`. macOS equivalents: `vm_stat` (with a `while` loop instead of `watch`), `ps -o vsz,rss`.

## Programs / commands

**exp6.c**
```c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    int mb;
    if (argc != 2)
    {
        printf("Usage: %s <memory_in_MB>\n", argv[0]);
        return 1;
    }

    mb = atoi(argv[1]);
    char *memory = malloc(mb * 1024 * 1024);

    if (memory == NULL)
    {
        printf("Memory allocation failed\n");
        return 1;
    }

    for (int i = 0; i < mb * 1024 * 1024; i += 4096)
    {
        memory[i] = 1;
    }
    printf("%d MB memory allocated.\n", mb);
    printf("Program is running... Press Ctrl+C to exit.\n");

    while (1)
    {
        sleep(1);
    }
    return 0;
}
```

**exp6_lazy.c**
```c
/* Same as exp6.c but touches the pages AFTER a pause, so the jump in RSS
   (page faults) can be observed separately from the malloc (VSZ) step. */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    if (argc != 2) { printf("Usage: %s <memory_in_MB>\n", argv[0]); return 1; }
    int mb = atoi(argv[1]);
    char *memory = malloc((size_t)mb * 1024 * 1024);
    if (memory == NULL) { printf("Memory allocation failed\n"); return 1; }

    printf("malloc done: %d MB reserved (virtual only)\n", mb); fflush(stdout);
    sleep(3);

    for (size_t i = 0; i < (size_t)mb * 1024 * 1024; i += 4096)
        memory[i] = 1;                       /* one write per 4096-byte page */
    printf("all pages touched\n"); fflush(stdout);

    while (1) sleep(1);
    return 0;
}
```

**run.sh**
```bash
#!/bin/bash
cd "$(dirname "$0")"
echo '$ ./exp6 100 &'
stdbuf -oL ./exp6 100 &
PID=$!
sleep 1
echo '$ ps -o pid,vsz,rss,comm -p '$PID' (KB)'
ps -o pid,vsz,rss,comm -p $PID
echo '$ free -m'
free -m
kill $PID; wait $PID 2>/dev/null
echo
echo "### Demand paging observed step by step (exp6_lazy 200)"
before=$(free -m | awk '/Mem:/{print $3}')
./exp6_lazy 200 &
PID=$!
for t in 1 2 3 4 5; do
  sleep 1
  printf 't=%ss  ' $t
  ps -o vsz=,rss= -p $PID | awk '{printf "VSZ=%d MB  RSS=%d MB\n",$1/1024,$2/1024}'
done
after=$(free -m | awk '/Mem:/{print $3}')
echo "system 'used' memory: before=${before} MB  after=${after} MB"
kill $PID; wait $PID 2>/dev/null
echo
echo "VSZ jumped as soon as malloc() ran; RSS stayed near 0 until the pages were written (t>=3s)."
```

## Procedure
1. Save the files above in one folder.
2. Compile C files with `gcc name.c -o name` and make scripts executable with `chmod +x name.sh`.
3. Run `bash run.sh` (or run each command by hand) and compare with the output below.

## Output
```
$ ./exp6 100 &
100 MB memory allocated.
Program is running... Press Ctrl+C to exit.
$ ps -o pid,vsz,rss,comm -p 1679 (KB)
  PID    VSZ   RSS COMMAND
 1679 105136 104292 exp6
$ free -m
               total        used        free      shared  buff/cache   available
Mem:            8027         567        7170          15         513        7459
Swap:              0           0           0

### Demand paging observed step by step (exp6_lazy 200)
malloc done: 200 MB reserved (virtual only)
t=1s  VSZ=202 MB  RSS=1 MB
t=2s  VSZ=202 MB  RSS=1 MB
t=3s  VSZ=202 MB  RSS=46 MB
all pages touched
t=4s  VSZ=202 MB  RSS=201 MB
t=5s  VSZ=202 MB  RSS=201 MB
system 'used' memory: before=463 MB  after=660 MB

VSZ jumped as soon as malloc() ran; RSS stayed near 0 until the pages were written (t>=3s).
```

**Note:** Captured on Linux with `ps` and `free`. On your Mac use: `./exp6 100` in one terminal and `while true; do clear; vm_stat; sleep 1; done` in another; "Pages free" will drop as the pages are touched.

## Conclusion
For the 200 MB test VSZ was about 202 MB right after malloc while RSS stayed at 1 MB; only after the write loop did RSS climb to about 201 MB and system used memory rise by roughly the same amount. This confirms demand paging.

## Viva questions

**Q1. Why did RSS not rise after malloc?**  
malloc only reserves virtual addresses; frames are assigned on first access.

**Q2. What is a page fault?**  
An exception when a process touches a page with no physical frame; the kernel handles it by allocating one.

**Q3. Why write every 4096 bytes?**  
That is the page size, so one write per page triggers every fault.

**Q4. VSZ vs RSS?**  
VSZ is virtual size reserved; RSS is the resident part in RAM.
