#!/bin/bash
# usage: ./logintime.sh username
# Prints how long the user has been logged in (works on macOS and Linux)
user=$1

if [ -z "$user" ]; then
    echo "usage: ./logintime.sh username"
    exit 1
fi

line=$(who | grep "^$user " | head -n 1)

if [ -z "$line" ]; then
    echo "$user is not currently logged in"
    exit 1
fi

login_date=$(echo "$line" | awk '{print $3}')
login_time=$(echo "$line" | awk '{print $4}')

if date -j >/dev/null 2>&1; then
    login_epoch=$(date -j -f "%Y-%m-%d %H:%M" "$login_date $login_time" +%s)   # macOS
else
    login_epoch=$(date -d "$login_date $login_time" +%s)                         # Linux
fi
now_epoch=$(date +%s)

diff=$((now_epoch - login_epoch))
hrs=$((diff / 3600))
mins=$(((diff % 3600) / 60))

echo "$user has been logged in for ${hrs}h ${mins}m"
