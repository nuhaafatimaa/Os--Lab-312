#include <stdio.h>
#include <unistd.h>

int main()
{
    int i = 0;
    while (1)
    {
        FILE *fp = fopen("io_output.txt", "a");
        if (fp == NULL) { perror("fopen"); return 1; }
        fprintf(fp, "I/O task write number %d\n", i++);
        fclose(fp);
        sleep(1);
    }
    return 0;
}
