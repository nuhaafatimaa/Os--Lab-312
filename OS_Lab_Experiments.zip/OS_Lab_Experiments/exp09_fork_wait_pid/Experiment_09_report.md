# Experiment 9: fork(), wait() and process IDs

## Aim
To write a C program that creates a child process, waits for it to terminate and prints its PID.

## Theory
- `getpid()` returns the calling process's ID, `getppid()` its parent's.
- `fork()` clones the process and returns 0 in the child, the child's PID in the parent and -1 on failure.
- `wait(NULL)` blocks the parent until the child ends and collects its status, which prevents a **zombie** (state Z).
- The order of unsynchronised prints between parent and child is a race decided by the scheduler; `wait()` guarantees the parent finishes after the child.

## Programs / commands

**experiment9.c**
```c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        exit(1);
    }
    else if (pid == 0)
    {
        /* child */
        printf("The child process ID (PID) is: %d\n", getpid());
        printf("The parent process ID (PPID) of child is: %d\n", getppid());
        sleep(1);
        printf("Child process finished.\n");
        exit(0);
    }
    else
    {
        /* parent */
        printf("The parent process (PID %d) waits until the child process finishes execution.\n", getpid());
        wait(NULL);                         /* reaps child, no zombie */
        printf("The PID of the child process is: %d\n", pid);
    }
    return 0;
}
```

**run.sh**
```bash
#!/bin/bash
cd "$(dirname "$0")"
echo '$ gcc experiment9.c -o experiment9'
echo '$ ./experiment9'
./experiment9
echo
echo "### Zombie demonstration (parent does NOT wait)"
cat > /tmp/zombie.c <<'Z'
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(){pid_t p=fork();if(p==0){exit(0);}sleep(3);return 0;}
Z
gcc -o /tmp/zombie /tmp/zombie.c
/tmp/zombie & ZP=$!
sleep 1
echo '$ ps -o pid,ppid,stat,comm --ppid '$ZP
ps -o pid,ppid,stat,comm --ppid $ZP
echo "(state Z = zombie: child finished but parent never called wait())"
wait $ZP; rm -f /tmp/zombie /tmp/zombie.c
```

## Procedure
1. Save the files above in one folder.
2. Compile C files with `gcc name.c -o name` and make scripts executable with `chmod +x name.sh`.
3. Run `bash run.sh` (or run each command by hand) and compare with the output below.

## Output
```
$ gcc experiment9.c -o experiment9
$ ./experiment9
The child process ID (PID) is: 1530
The parent process ID (PPID) of child is: 1529
Child process finished.
The parent process (PID 1529) waits until the child process finishes execution.
The PID of the child process is: 1530

### Zombie demonstration (parent does NOT wait)
$ ps -o pid,ppid,stat,comm --ppid 1537
  PID  PPID STAT COMMAND
 1539  1537 Z    zombie
(state Z = zombie: child finished but parent never called wait())
```

**Note:** Your screenshot used the sample PID 12345; real PIDs differ on every run.

## Conclusion
The parent forked a child, the child printed its PID and finished, and the parent waited and printed the same PID. Removing wait() left the child as a zombie (state Z).

## Viva questions

**Q1. What does fork() return?**  
0 to the child, the child's PID to the parent, -1 on error.

**Q2. Why use wait()?**  
To block until the child ends and reap it, avoiding a zombie.

**Q3. What is a zombie?**  
A finished child whose parent has not yet collected its status.

**Q4. What is an orphan?**  
A child whose parent exited first; init adopts it.
