# Experiment 5: String length and substring in Bash and C, with timing using `time`

## Aim
To find the length of a string and extract a substring in Bash (`${#str}`, `${str:start:length}`) and in C (null-terminator loop and buffer copy), and compare them with the `time` utility (real, user, sys).

## Theory
- Bash: `${#str}` gives the length, `${str:start:length}` the substring (index starts at 0).
- C: a string ends with `'\0'`; the length is found by looping until it, and the substring by copying characters into another buffer and adding `'\0'`.
- `time`: **real** = wall-clock time, **user** = CPU time in the program, **sys** = CPU time in the kernel.
- Bash is interpreted line by line, C is compiled to machine code, so C is much faster for repeated work.

## Programs / commands

**exp5.sh**
```bash
#!/bin/bash
read -p "Enter a string: " str
echo "Length of string: ${#str}"
read -p "Enter starting position: " start
read -p "Enter number of characters: " length
echo "Substring: ${str:$start:$length}"
```

**exp5.c**
```c
#include <stdio.h>

int main() {
    char str[200], sub[200];
    int len = 0, start, count, i;

    printf("Enter a string: ");
    scanf(" %[^\n]", str);

    /* length: walk until the null terminator */
    while (str[len] != '\0')
        len++;
    printf("Length of string: %d\n", len);

    printf("Enter starting position: ");
    scanf("%d", &start);
    printf("Enter number of characters: ");
    scanf("%d", &count);

    /* substring: copy characters into a buffer */
    for (i = 0; i < count && start + i < len; i++)
        sub[i] = str[start + i];
    sub[i] = '\0';

    printf("Substring: %s\n", sub);
    return 0;
}
```

**feed.py**
```python
import pty, os, sys, select, time
cmd, answers = sys.argv[1], sys.argv[2:]
pid, fd = pty.fork()
if pid == 0:
    os.execvp(cmd, [cmd])
buf = b""; i = 0
def pump(t=0.4):
    global buf
    while select.select([fd], [], [], t)[0]:
        try: d = os.read(fd, 1024)
        except OSError: return False
        if not d: return False
        sys.stdout.write(d.decode().replace("\r", "")); sys.stdout.flush()
    return True
while True:
    alive = pump()
    if i < len(answers) and alive:
        os.write(fd, (answers[i] + "\n").encode()); i += 1
    elif not alive: break
    elif i >= len(answers):
        if not pump(0.5): break
        break
os.waitpid(pid, 0)
```

**run.sh**
```bash
#!/bin/bash
cd "$(dirname "$0")"
TIMEFORMAT='real %3Rs  user %3Us  sys %3Ss'
echo "### Bash version (exp5.sh)"
echo '$ ./exp5.sh'
python3 feed.py ./exp5.sh 'hello world' 2 7
echo
echo "### C version (exp5)"
echo '$ ./exp5'
python3 feed.py ./exp5 'hello world' 3 6
echo
echo "### Timing one run each"
echo '$ time ./exp5.sh'
time (printf 'hello world\n2\n7\n' | ./exp5.sh >/dev/null)
echo '$ time ./exp5'
time (printf 'hello world\n3\n6\n' | ./exp5 >/dev/null)
echo
echo "### Fair benchmark: same operation repeated 100000 times"
cat > /tmp/bench.sh <<'B'
str="Model Institute of Engineering and Technology"
for ((i=0;i<100000;i++)); do len=${#str}; sub=${str:6:9}; done
echo "bash: length=$len substring=$sub"
B
cat > /tmp/bench.c <<'B'
#include <stdio.h>
int main(){char s[]="Model Institute of Engineering and Technology",sub[50];int len=0,i,n;volatile int sink=0;
for(n=0;n<100000;n++){len=0;while(s[len])len++;for(i=0;i<9;i++)sub[i]=s[6+i];sub[9]=0;sink+=len+sub[0];}
printf("C   : length=%d substring=%s\n",len,sub);return 0;}
B
gcc -O0 -o /tmp/bench /tmp/bench.c
echo '$ time bash bench.sh'
time bash /tmp/bench.sh
echo '$ time ./bench'
time /tmp/bench
rm -f /tmp/bench /tmp/bench.c /tmp/bench.sh
```

## Procedure
1. Save the files above in one folder.
2. Compile C files with `gcc name.c -o name` and make scripts executable with `chmod +x name.sh`.
3. Run `bash run.sh` (or run each command by hand) and compare with the output below.

## Output
```
### Bash version (exp5.sh)
$ ./exp5.sh
Enter a string: hello world
Length of string: 11
Enter starting position: 2
Enter number of characters: 7
Substring: llo wor

### C version (exp5)
$ ./exp5
Enter a string: hello world
Length of string: 11
Enter starting position: 3
Enter number of characters: 6
Substring: lo wor

### Timing one run each
$ time ./exp5.sh
real 0.003s  user 0.001s  sys 0.002s
$ time ./exp5
real 0.002s  user 0.002s  sys 0.000s

### Fair benchmark: same operation repeated 100000 times
$ time bash bench.sh
bash: length=45 substring=Institute
real 0.380s  user 0.374s  sys 0.000s
$ time ./bench
C   : length=45 substring=Institute
real 0.012s  user 0.008s  sys 0.004s
```

**Note:** `feed.py` only types the answers into the prompts so the transcript looks like an interactive session. For your record, run `./exp5.sh` and `./exp5` yourself and type the inputs. On your Mac, `time` prints the format shown in your screenshot.

## Conclusion
Both versions give identical results ("hello world": length 11, substring from 2 of 7 = "llo wor"). A single run takes about a millisecond in both, so a 100,000-iteration benchmark was used: C finished about 40 times faster than Bash.

## Viva questions

**Q1. What does `${#str}` return?**  
The number of characters in `str`.

**Q2. Why does a C string need `\0`?**  
It marks the end of the string since C stores no length.

**Q3. Difference between real, user and sys?**  
Elapsed time, CPU time in user code, CPU time in the kernel.

**Q4. Why is C faster than Bash?**  
C is compiled; Bash is interpreted at run time.
