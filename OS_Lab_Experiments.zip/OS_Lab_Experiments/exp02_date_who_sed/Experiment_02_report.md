# Experiment 2: date and who with redirection, and sed to swap the first two words of each line

## Aim
To run `date` and `who` in one line so that date prints on the screen while who goes to a file, and to write a sed command that swaps the first and second word of every line of a file.

## Theory
- `;` runs commands one after another on one line.
- `date; who > who.txt`: `date` writes to the screen, only `who` is redirected into `who.txt`.
- `w` shows who is logged in and what they are doing (the screenshot in your record uses `date; w | cat > who.txt`).
- `sed` is a stream editor; `s/pattern/replacement/` substitutes text; `\( \)` (or `( )` with `-E`) capture groups that `\1`, `\2` reuse.
- `sed -i.bak` edits the file in place and keeps the original as `file.bak`.

## Programs / commands

**name.txt**
```
Nuha Fatima
Harshita Sharma
Manaya Sharma
```

**run.sh**
```bash
#!/bin/bash
export TZ=IST-5:30
r() { echo "\$ $*"; eval "$@"; }
cd "$(dirname "$0")"; cp name.txt work.txt
echo "### Part A: date on screen, who output redirected to a file"
r 'date; who > who.txt'
r cat who.txt
echo "(who.txt is empty here only because this sandbox has no logged-in terminal users; on your Mac it lists your sessions)"
r 'date; w | cat > w.txt'
r cat w.txt
echo
echo "### Part B: sed - swap first and second word of every line"
r cat work.txt
r "sed -E 's/^([^ ]+) ([^ ]+)/\2 \1/' work.txt"
r "sed -i.bak 's/^\([^ ]*\) \(.*\)$/\2 \1/' work.txt"
r cat work.txt
r cat work.txt.bak
rm -f who.txt w.txt work.txt work.txt.bak
```

## Procedure
1. Save the files above in one folder.
2. Compile C files with `gcc name.c -o name` and make scripts executable with `chmod +x name.sh`.
3. Run `bash run.sh` (or run each command by hand) and compare with the output below.

## Output
```
### Part A: date on screen, who output redirected to a file
$ date; who > who.txt
Tue Nov  3 10:52:33 IST 2026
$ cat who.txt
(who.txt is empty here only because this sandbox has no logged-in terminal users; on your Mac it lists your sessions)
$ date; w | cat > w.txt
Tue Nov  3 10:52:33 IST 2026
$ cat w.txt
 10:52:33 up 3 min,  0 user,  load average: 0.16, 0.08, 0.02
USER     TTY      FROM             LOGIN@   IDLE   JCPU   PCPU  WHAT

### Part B: sed - swap first and second word of every line
$ cat work.txt
Nuha Fatima
Harshita Sharma
Manaya Sharma
$ sed -E 's/^([^ ]+) ([^ ]+)/\2 \1/' work.txt
Fatima Nuha
Sharma Harshita
Sharma Manaya
$ sed -i.bak 's/^\([^ ]*\) \(.*\)$/\2 \1/' work.txt
$ cat work.txt
Fatima Nuha
Sharma Harshita
Sharma Manaya
$ cat work.txt.bak
Nuha Fatima
Harshita Sharma
Manaya Sharma
```

## Conclusion
date appeared on screen while the who/w output was stored in a file, and sed swapped the first two words of each line (Nuha Fatima became Fatima Nuha), with the original preserved in the .bak file.

## Viva questions

**Q1. Why does only `who` go to the file in `date; who > who.txt`?**  
Redirection applies only to the command it follows; `date` is a separate command.

**Q2. What does `\1` mean in sed?**  
The text captured by the first `\( \)` group.

**Q3. What does `-i.bak` do?**  
Edits in place and saves a backup copy with the .bak suffix.
