#!/bin/bash
# Renames every file given as argument to UPPER CASE
for file in "$@"
do
    if [ -f "$file" ]
    then
        mv "$file" "$(echo "$file" | tr '[:lower:]' '[:upper:]')"
        echo "file name changed to upper case"
    else
        echo "$file does not exist"
    fi
done
