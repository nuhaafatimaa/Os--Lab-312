#!/bin/bash
# Reads a name and reports whether it is a file, a directory, or neither
echo "Enter a file or directory"
read n
if [ -d "$n" ]
then
    echo "$n is a directory"
elif [ -f "$n" ]
then
    echo "$n is a file"
else
    echo "$n is neither directory nor file"
fi
