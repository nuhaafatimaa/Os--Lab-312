#!/bin/bash
cd "$(dirname "$0")"
./mem_map > /tmp/mm.out & PID=$!
sleep 1; cat /tmp/mm.out
echo
echo "\$ pmap -x $PID"
pmap -x $PID
echo
echo "### Checking the invariant  Dirty <= RSS <= Kbytes  on every mapping"
pmap -x $PID | awk 'NR>2 && $2 ~ /^[0-9]+$/ { ok=($4<=$3 && $3<=$2)?"OK":"VIOLATION"; printf "%-18s Kbytes=%-7s RSS=%-7s Dirty=%-7s %s\n",$1,$2,$3,$4,ok; if(ok=="OK")g++; else b++ } END{printf "\nmappings OK: %d   violations: %d\n",g,b+0}'
kill $PID; wait $PID 2>/dev/null; rm -f /tmp/mm.out
