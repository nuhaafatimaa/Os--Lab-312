# Experiment 4: Shell scripts: rename files to upper case, delete lines containing a word, login duration of a user

## Aim
To write scripts that rename files to upper case, delete from files every line containing a given word, and compute how long a user has been logged in.

## Theory
- `tr '[:lower:]' '[:upper:]'` converts lowercase letters to uppercase; `mv` renames the file to the converted name.
- `for file in "$@"` loops over all arguments; `shift` drops the first argument (the word) so the rest are files.
- `sed -i "/word/d"` deletes every line matching the word.
- `who` gives the login time; `date +%s` converts times to seconds so the difference can be turned into hours and minutes with `$(( ))`.
- On macOS the login time is parsed with `date -j -f`; on Linux with `date -d`. The script handles both.

## Programs / commands

**upper.sh**
```bash
#!/bin/bash
# Renames every file given as argument to UPPER CASE
for file in "$@"
do
    if [ -f "$file" ]
    then
        mv "$file" "$(echo "$file" | tr '[:lower:]' '[:upper:]')"
        echo "file name changed to upper case"
    else
        echo "$file does not exist"
    fi
done
```

**delword.sh**
```bash
#!/bin/bash
# usage: ./delword.sh word file1 file2 ...
# Deletes every line containing the word from each file
word=$1
shift

if [ -z "$word" ] || [ "$#" -eq 0 ]; then
    echo "usage: ./delword.sh word file1 [file2 ...]"
    exit 1
fi

for file in "$@"
do
    if [ -f "$file" ]; then
        sed -i.bak "/$word/d" "$file" && rm -f "$file.bak"
        echo "removed lines containing '$word' from $file"
    else
        echo "$file does not exist"
    fi
done
```

**logintime.sh**
```bash
#!/bin/bash
# usage: ./logintime.sh username
# Prints how long the user has been logged in (works on macOS and Linux)
user=$1

if [ -z "$user" ]; then
    echo "usage: ./logintime.sh username"
    exit 1
fi

line=$(who | grep "^$user " | head -n 1)

if [ -z "$line" ]; then
    echo "$user is not currently logged in"
    exit 1
fi

login_date=$(echo "$line" | awk '{print $3}')
login_time=$(echo "$line" | awk '{print $4}')

if date -j >/dev/null 2>&1; then
    login_epoch=$(date -j -f "%Y-%m-%d %H:%M" "$login_date $login_time" +%s)   # macOS
else
    login_epoch=$(date -d "$login_date $login_time" +%s)                         # Linux
fi
now_epoch=$(date +%s)

diff=$((now_epoch - login_epoch))
hrs=$((diff / 3600))
mins=$(((diff % 3600) / 60))

echo "$user has been logged in for ${hrs}h ${mins}m"
```

**todo.txt**
```
buy groceries
finish CSE 512 lab file
draft error report
submit error report
clean the desk
```

**run.sh**
```bash
#!/bin/bash
r() { echo "\$ $*"; eval "$@"; }
cd "$(dirname "$0")"; W=$(mktemp -d); cp *.sh todo.txt "$W"; cd "$W"
echo "### Part A: rename files to upper case"
touch file3.txt file4.txt new.txt
r ls
r ./upper.sh file3.txt file4.txt new.txt nofile.txt
r ls
echo
echo "### Part B: delete lines containing a word"
r cat todo.txt
r ./delword.sh error todo.txt
r cat todo.txt
r ./delword.sh error
echo
echo "### Part C: login duration of a user (simulated 'who', see note)"
mkdir bin
login=$(date -d '69 minutes ago' '+%Y-%m-%d %H:%M')
printf '#!/bin/bash\necho "nuhafatima console  %s"\n' "$login" > bin/who; chmod +x bin/who
echo "note: a mock 'who' is placed first in PATH so the output does not depend on this sandbox's sessions"
r 'PATH=$PWD/bin:$PATH who'
r 'PATH=$PWD/bin:$PATH ./logintime.sh nuhafatima'
r 'PATH=$PWD/bin:$PATH ./logintime.sh nobody'
cd /; rm -rf "$W"
```

## Procedure
1. Save the files above in one folder.
2. Compile C files with `gcc name.c -o name` and make scripts executable with `chmod +x name.sh`.
3. Run `bash run.sh` (or run each command by hand) and compare with the output below.

## Output
```
### Part A: rename files to upper case
$ ls
delword.sh
file3.txt
file4.txt
logintime.sh
new.txt
run.sh
todo.txt
upper.sh
$ ./upper.sh file3.txt file4.txt new.txt nofile.txt
file name changed to upper case
file name changed to upper case
file name changed to upper case
nofile.txt does not exist
$ ls
FILE3.TXT
FILE4.TXT
NEW.TXT
delword.sh
logintime.sh
run.sh
todo.txt
upper.sh

### Part B: delete lines containing a word
$ cat todo.txt
buy groceries
finish CSE 512 lab file
draft error report
submit error report
clean the desk
$ ./delword.sh error todo.txt
removed lines containing 'error' from todo.txt
$ cat todo.txt
buy groceries
finish CSE 512 lab file
clean the desk
$ ./delword.sh error
usage: ./delword.sh word file1 [file2 ...]

### Part C: login duration of a user (simulated 'who', see note)
note: a mock 'who' is placed first in PATH so the output does not depend on this sandbox's sessions
$ PATH=$PWD/bin:$PATH who
nuhafatima console  2026-11-03 04:13
$ PATH=$PWD/bin:$PATH ./logintime.sh nuhafatima
nuhafatima has been logged in for 1h 9m
$ PATH=$PWD/bin:$PATH ./logintime.sh nobody
nobody is not currently logged in
```

## Conclusion
Three files were renamed to upper case (a missing file was reported), both "error" lines were deleted from todo.txt, and the login script reported 1h 9m for a session that started 69 minutes earlier.

## Viva questions

**Q1. What does `shift` do?**  
Removes `$1` and moves the remaining arguments down by one.

**Q2. What does `"$@"` represent?**  
All arguments, each kept as a separate word.

**Q3. Why convert times to epoch seconds?**  
Subtracting two plain numbers is easy; epoch seconds give an exact difference.
